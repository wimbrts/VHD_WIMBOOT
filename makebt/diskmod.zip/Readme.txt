Karyonix � diskmod.sys

http://reboot.pro/topic/9461-page-file-in-usb-hard-disk/#entry86619

Diskmod.sys was originally written to allow pagefile.sys to reside in a USB Hard Disk.However its other features include disguising UFDs as HDDs and HDDs as UFDs.

Install and use diskmod.sys
1.Download and extract diskmod-0.0.2.2.zip
2.Right Click on diskmod.inf � Install
3.Run UFDasHDD.bat and replug your USB Flash Drive to make it appear as Fixed Disk
4.Run UFDNormal.bat and replug your USB Flash Drive to make it appear normally as Removable Media
5.Run USBHDDasUFD.bat and replug your USB Hard Disk to make it appear as Removable Media
6.Run USBHDDnormal.bat and replug your USB Hard Disk to make it appear normally as Fixed Disk.
Features
USB Flash Drives can be disguised as USB HDDs
USB HDDs can be disguised as USB Flash Drives.This feature was missing in cfadisk.sys and dummydisk.sys
Easy to install.No Reboot required
Very easy to switch between Removable and Fixed modes for both USB Flash Drives and USB HDDs.You just have to change a value in the registry and replug your USB Device
All connected USB Devices are affected.Karyonix�s post at reboot.pro mentions that individual USB Devices can be targetted without affecting the other connected USB Devices.However I have not been able to get that setting working
Diskmod is one of the best filter drivers available for disguising a UFD as a USB HDD or vice versa.
